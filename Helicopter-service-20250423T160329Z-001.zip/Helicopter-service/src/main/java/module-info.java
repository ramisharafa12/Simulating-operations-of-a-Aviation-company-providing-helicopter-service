module com.example.helicopterservice {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.logging;


    opens com.example.helicopterservice to javafx.fxml;
    exports com.example.helicopterservice;
}