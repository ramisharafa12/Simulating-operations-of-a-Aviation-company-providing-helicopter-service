package com.example.helicopterservice;

import java.io.Serializable;

public class RequetReturn implements Serializable {
    private String bookingNumber;
    private  String paitentname;
    private  String location;
    private  String mobileNumber;

    public RequetReturn(String bookingNumber, String paitentname, String location, String mobileNumber) {
        this.bookingNumber = bookingNumber;
        this.paitentname = paitentname;
        this.location = location;
        this.mobileNumber = mobileNumber;
    }

    public String getBookingNumber() {
        return bookingNumber;
    }

    public void setBookingNumber(String bookingNumber) {
        this.bookingNumber = bookingNumber;
    }

    public String getPaitentname() {
        return paitentname;
    }

    public void setPaitentname(String paitentname) {
        this.paitentname = paitentname;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    @Override
    public String toString() {
        return "RequetReturn{" +
                "bookingNumber='" + bookingNumber + '\'' +
                ", paitentname='" + paitentname + '\'' +
                ", location='" + location + '\'' +
                ", mobileNumber='" + mobileNumber + '\'' +
                '}';
    }
}
