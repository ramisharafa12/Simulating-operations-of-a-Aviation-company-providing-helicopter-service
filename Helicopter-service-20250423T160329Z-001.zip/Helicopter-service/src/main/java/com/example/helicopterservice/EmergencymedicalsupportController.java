package com.example.helicopterservice;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.*;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EmergencymedicalsupportController {
    @javafx.fxml.FXML
    private TextField conditonTExtfield;
    @javafx.fxml.FXML
    private TableColumn<EmergencySupport,String> locatoonColumn;
    @javafx.fxml.FXML
    private TextField paitentnameTExtfield;
    @javafx.fxml.FXML
    private TableColumn<EmergencySupport,String> paitentNAmeColumn;
    @javafx.fxml.FXML
    private TableColumn<EmergencySupport,String> oxygenColumn;
    @javafx.fxml.FXML
    private TableView<EmergencySupport> tableView;
    @javafx.fxml.FXML
    private TextField locationTExtfield;
    @javafx.fxml.FXML
    private ComboBox<String> oxygencombobox;
    @javafx.fxml.FXML
    private TableColumn<EmergencySupport,String> conditionColumn;

    @javafx.fxml.FXML
    public void initialize() {
        oxygencombobox.getItems().addAll("Yes","No");
        conditionColumn.setCellValueFactory(new PropertyValueFactory<>("condition"));
        paitentNAmeColumn.setCellValueFactory(new PropertyValueFactory<>("paitentNAme"));
        oxygenColumn.setCellValueFactory(new PropertyValueFactory<>("emergencyOxygen"));
        locatoonColumn.setCellValueFactory(new PropertyValueFactory<>("locaton"));
        loadAllData();




    }
    @javafx.fxml.FXML
    public void addButton(ActionEvent actionEvent) {
        String name=paitentnameTExtfield.getText();
        String condition=conditonTExtfield.getText();
        String location=locationTExtfield.getText();
        String emergencyOxygen=oxygencombobox.getValue();
        File f= null;
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try{
            f=new File("EmergencySupport.bin");
            if(f.exists()){
                fos=new FileOutputStream(f,true);
                oos=new AppendableObjectOutPutStream(fos);
            }
            else{
                fos=new FileOutputStream(f);
                oos=new ObjectOutputStream(fos);
            }
            EmergencySupport y=new EmergencySupport(name,condition,location,emergencyOxygen);
            tableView.getItems().add(y);
            oos.writeObject(y);

        }catch(IOException ex){
            Logger.getLogger(EmergencymedicalsupportController.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
            try {
                if (oos != null) {
                    oos.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(EmergencymedicalsupportController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }



    }
    public void loadAllData() {
        ObjectInputStream ois = null;
        try {
            EmergencySupport y;
            ois = new ObjectInputStream(new FileInputStream("EmergencySupport.bin"));
            while (true) {
                y = (EmergencySupport) ois.readObject();
                tableView.getItems().add(y);
            }
        } catch (Exception ex) {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex2) {
                ex2.printStackTrace();
            }
            ex.printStackTrace();
        }
    }


    @javafx.fxml.FXML
    public void submitRequestbutton(ActionEvent actionEvent) {
        tableView.getItems().clear();
        loadAllData();
    }

    @javafx.fxml.FXML
    public void logoutbutton(ActionEvent event) throws IOException {
        Parent scene2Parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/helicopterservice/MedicalCustomerDashboard.fxml")));
        Scene scene2 = new Scene(scene2Parent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("EmergencyHelicopterService");
        window.setScene(scene2);
        window.show();
    }
}
