package com.example.helicopterservice;

import java.io.Serializable;
import java.time.LocalDate;

public class NonEmergency implements Serializable {
    private String pickuploction;
    private String drop;
    private String medicalAss;
    private LocalDate date;

    public NonEmergency(String pickuploction, String drop, String medicalAss, LocalDate date) {
        this.pickuploction = pickuploction;
        this.drop = drop;
        this.medicalAss = medicalAss;
        this.date = date;
    }

    public String getPickuploction() {
        return pickuploction;
    }

    public void setPickuploction(String pickuploction) {
        this.pickuploction = pickuploction;
    }

    public String getDrop() {
        return drop;
    }

    public void setDrop(String drop) {
        this.drop = drop;
    }

    public String getMedicalAss() {
        return medicalAss;
    }

    public void setMedicalAss(String medicalAss) {
        this.medicalAss = medicalAss;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "NonEmergency{" +
                "pickuploction='" + pickuploction + '\'' +
                ", drop='" + drop + '\'' +
                ", medicalAss='" + medicalAss + '\'' +
                ", date=" + date +
                '}';
    }
}
