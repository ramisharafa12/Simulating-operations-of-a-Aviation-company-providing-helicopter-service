package com.example.helicopterservice;

import java.io.Serializable;

public class CancellSchuduleFlight implements Serializable {
    private String bookingNumber;
    private String location;
    private String Reason;
    private String vip;

    public CancellSchuduleFlight(String bookingNumber, String location, String reason, String vip) {
        this.bookingNumber = bookingNumber;
        this.location = location;
        Reason = reason;
        this.vip = vip;
    }

    public String getBookingNumber() {
        return bookingNumber;
    }

    public void setBookingNumber(String bookingNumber) {
        this.bookingNumber = bookingNumber;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getReason() {
        return Reason;
    }

    public void setReason(String reason) {
        Reason = reason;
    }

    public String getVip() {
        return vip;
    }

    public void setVip(String vip) {
        this.vip = vip;
    }

    @Override
    public String toString() {
        return "CancellSchuduleFlight{" +
                "bookingNumber='" + bookingNumber + '\'' +
                ", location='" + location + '\'' +
                ", Reason='" + Reason + '\'' +
                ", vip='" + vip + '\'' +
                '}';
    }
}
