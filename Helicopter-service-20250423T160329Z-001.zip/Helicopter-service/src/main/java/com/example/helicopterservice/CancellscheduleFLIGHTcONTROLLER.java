package com.example.helicopterservice;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CancellscheduleFLIGHTcONTROLLER {

    @FXML
    private TextField bookingnuvberTextfield;


    @FXML
    private TextField locationTextField;


    @FXML
    private TextField reasonTextField;

    @FXML
    private ComboBox<String> vIpcombobox;
    @FXML
    private TableColumn<CancellSchuduleFlight,String> bookingnumberColumn;
    @FXML
    private TableView tableview;
    @FXML
    private TableColumn vipcolumn;
    @FXML
    private TableColumn reasonColumn;
    @FXML
    private TableColumn locationColumn;


    @javafx.fxml.FXML
    public void initialize() {
        vIpcombobox.getItems().addAll("Yes","No");
        vipcolumn.setCellValueFactory(new PropertyValueFactory<>("vip"));
        bookingnumberColumn.setCellValueFactory(new PropertyValueFactory<>("bookingNumber"));
        reasonColumn.setCellValueFactory(new PropertyValueFactory<>("Reason"));
        locationColumn.setCellValueFactory(new PropertyValueFactory<>("location"));
        loadAll();




    }

    @FXML
    void addButton(ActionEvent event) {
        String bookingNUMBER=bookingnuvberTextfield.getText();
        String  location=locationTextField.getText();
        String reason=reasonTextField.getText();
        String vip=vIpcombobox.getValue();
        File f= null;
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try{
            f=new File("CancelBooking.bin");
            if(f.exists()){
                fos=new FileOutputStream(f,true);
                oos=new AppendableObjectOutPutStream(fos);
            }
            else{
                fos=new FileOutputStream(f);
                oos=new ObjectOutputStream(fos);
            }
            CancellSchuduleFlight y=new CancellSchuduleFlight(bookingNUMBER,location,reason,vip);
            tableview.getItems().add(y);
            oos.writeObject(y);

        }catch(IOException ex){
            Logger.getLogger(CancellscheduleFLIGHTcONTROLLER.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
            try {
                if (oos != null) {
                    oos.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(CancellscheduleFLIGHTcONTROLLER.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public void loadAll() {
        ObjectInputStream ois = null;
        try {
            CancellSchuduleFlight y;
            ois = new ObjectInputStream(new FileInputStream("CancelBooking.bin"));
            while (true) {
                y = (CancellSchuduleFlight) ois.readObject();
                tableview.getItems().add(y);
            }
        } catch (Exception ex) {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex2) {
                ex2.printStackTrace();
            }
            ex.printStackTrace();
        }
    }


    @FXML
    void cancellRequest(ActionEvent event) {
        tableview.getItems().clear();
        loadAll();

    }

}
