package com.example.helicopterservice;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RequestReturnTripController {

    @FXML
    private TextField bookingNumberText;

    @FXML
    private TableColumn<?, ?> bookingcolumn;

    @FXML
    private TableColumn<?, ?> locationColumn;

    @FXML
    private TextField locationText;

    @FXML
    private TableColumn<?, ?> mobilecolummn;

    @FXML
    private TextField mobilrnumberText;

    @FXML
    private TableColumn<?, ?> paitentcolumn;

    @FXML
    private TextField paitentnameTextfield;

    @FXML
    private TableView<RequetReturn> tableview;

    @javafx.fxml.FXML
    public void initialize() {
        paitentcolumn.setCellValueFactory(new PropertyValueFactory<>("paitentname"));
        mobilecolummn.setCellValueFactory(new PropertyValueFactory<>("mobileNumber"));
        locationColumn.setCellValueFactory(new PropertyValueFactory<>("location"));
        bookingcolumn.setCellValueFactory(new PropertyValueFactory<>("bookingNumber"));
        loadall();



    }

    @FXML
    void addButton(ActionEvent event) {

        String bookingNumber=bookingNumberText.getText();
        String paitent=paitentnameTextfield.getText();
        String location=locationText.getText();
        String mobileNumber=mobilrnumberText.getText();
        File f= null;
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try{
            f=new File("RequestReturn.bin");
            if(f.exists()){
                fos=new FileOutputStream(f,true);
                oos=new AppendableObjectOutPutStream(fos);
            }
            else{
                fos=new FileOutputStream(f);
                oos=new ObjectOutputStream(fos);
            }
            RequetReturn y=new RequetReturn(bookingNumber,paitent,location,mobileNumber);
            tableview.getItems().add(y);
            oos.writeObject(y);

        }catch(IOException ex){
            Logger.getLogger(RequestReturnTripController.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
            try {
                if (oos != null) {
                    oos.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(RequestReturnTripController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public void loadall(){
        ObjectInputStream ois = null;
        try {
            RequetReturn y;
            ois = new ObjectInputStream(new FileInputStream("RequestReturn.bin"));
            while (true) {
                y = (RequetReturn) ois.readObject();
                tableview.getItems().add(y);
            }
        } catch (Exception ex) {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex2) {
                ex2.printStackTrace();
            }
            ex.printStackTrace();
        }
    }

    @FXML
    void returnTripButton(ActionEvent event) {
        tableview.getItems().clear();
        loadall();
    }

}
