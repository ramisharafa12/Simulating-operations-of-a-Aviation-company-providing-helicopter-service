package com.example.helicopterservice;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class MedicalCustomerDashboardController {
    @javafx.fxml.FXML
    public void EmergencyMEdicalSuport(ActionEvent event) throws IOException {
        Parent scene2Parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/helicopterservice/emergencymedicalsupport.fxml")));
        Scene scene2 = new Scene(scene2Parent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("EmergencyHelicopterService");
        window.setScene(scene2);
        window.show();
    }

    @javafx.fxml.FXML
    public void nonEmergencyMEdicalsupport(ActionEvent event) throws IOException {
        Parent scene2Parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/helicopterservice/nonEmergencysupport.fxml")));
        Scene scene2 = new Scene(scene2Parent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("NonEmergencyHelicopterService");
        window.setScene(scene2);
        window.show();
    }

    @javafx.fxml.FXML
    public void cancellFight(ActionEvent event) throws IOException {
        Parent scene2Parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/helicopterservice/cancellscheduleFLIGHT.fxml")));
        Scene scene2 = new Scene(scene2Parent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("NonEmergencyHelicopterService");
        window.setScene(scene2);
        window.show();
    }
    @javafx.fxml.FXML
    public void requestReturntrip(ActionEvent event) throws IOException {
        Parent scene2Parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/helicopterservice/requestReturnTrip.fxml")));
        Scene scene2 = new Scene(scene2Parent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setTitle("NonEmergencyHelicopterService");
        window.setScene(scene2);
        window.show();
    }
}
