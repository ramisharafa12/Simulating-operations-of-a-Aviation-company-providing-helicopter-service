package com.example.helicopterservice;

import java.io.Serializable;

public class EmergencySupport implements Serializable {
    private String paitentNAme;
    private String condition;
    private String locaton;
    private String emergencyOxygen;

    public EmergencySupport(String paitentNAme, String condition, String locaton, String emergencyOxygen) {
        this.paitentNAme = paitentNAme;
        this.condition = condition;
        this.locaton = locaton;
        this.emergencyOxygen = emergencyOxygen;
    }

    public String getPaitentNAme() {
        return paitentNAme;
    }

    public void setPaitentNAme(String paitentNAme) {
        this.paitentNAme = paitentNAme;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getLocaton() {
        return locaton;
    }

    public void setLocaton(String locaton) {
        this.locaton = locaton;
    }

    public String getEmergencyOxygen() {
        return emergencyOxygen;
    }

    public void setEmergencyOxygen(String emergencyOxygen) {
        this.emergencyOxygen = emergencyOxygen;
    }

    @Override
    public String toString() {
        return "EmergencySupport{" +
                "paitentNAme='" + paitentNAme + '\'' +
                ", condition='" + condition + '\'' +
                ", locaton='" + locaton + '\'' +
                ", emergencyOxygen='" + emergencyOxygen + '\'' +
                '}';
    }
}
