package com.example.helicopterservice;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NonEmergencysupportController {

    @FXML
    private TableColumn<NonEmergency, LocalDate> dateColumn;

    @FXML
    private DatePicker datePicker;

    @FXML
    private TableColumn<NonEmergency, String> dropColumn;

    @FXML
    private TextField dropTextField;

    @FXML
    private ComboBox<String> medicalAssistanceTextField;

    @FXML
    private TableColumn<NonEmergency, String> medicalassColumn;

    @FXML
    private TableColumn<NonEmergency, String> pickubColumn;

    @FXML
    private TextField pickupTextField;

    @FXML
    private TableView<NonEmergency> tableview;

    @javafx.fxml.FXML
    public void initialize() {
        medicalAssistanceTextField.getItems().addAll("Yes","No");
        medicalassColumn.setCellValueFactory(new PropertyValueFactory<NonEmergency,String>("medicalAss"));
        pickubColumn.setCellValueFactory(new PropertyValueFactory<NonEmergency,String>("pickuploction"));
        dropColumn.setCellValueFactory(new PropertyValueFactory<NonEmergency,String>("drop"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<NonEmergency,LocalDate>("date"));
        loadAll();


    }

    @FXML
    public void add(ActionEvent actionEvent) {
        String pickupL=pickupTextField.getText();
        String drop=dropTextField.getText();
        String medicalAss=medicalAssistanceTextField.getValue();
        LocalDate date=datePicker.getValue();
        File f= null;
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try{
            f=new File("NonEmergency.bin");
            if(f.exists()){
                fos=new FileOutputStream(f,true);
                oos=new AppendableObjectOutPutStream(fos);
            }
            else{
                fos=new FileOutputStream(f);
                oos=new ObjectOutputStream(fos);
            }
            NonEmergency y=new NonEmergency(pickupL,drop,medicalAss,date);
            tableview.getItems().add(y);
            oos.writeObject(y);

        }catch(IOException ex){
            Logger.getLogger(NonEmergencysupportController.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
            try {
                if (oos != null) {
                    oos.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(NonEmergencysupportController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public void  loadAll(){
        ObjectInputStream ois = null;
        try {
            NonEmergency y;
            ois = new ObjectInputStream(new FileInputStream("NonEmergency.bin"));
            while (true) {
                y = (NonEmergency) ois.readObject();
                tableview.getItems().add(y);
            }
        } catch (Exception ex) {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex2) {
                ex2.printStackTrace();
            }
            ex.printStackTrace();
        }
    }

    @FXML
    public void request(ActionEvent actionEvent) {
        tableview.getItems().clear();
        loadAll();
    }
}
